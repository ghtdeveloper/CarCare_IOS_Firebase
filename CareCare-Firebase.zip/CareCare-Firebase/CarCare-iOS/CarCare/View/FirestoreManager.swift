//
//  FirestoreManager.swift
//  CarCare
//
//  Created by user207369 on 3/27/22.
//

import Foundation
import Firebase

class FirestoreManager: ObservableObject
{
    
    //@Published var taller : String = ""
    @Published var listNombreTaller = [String] ()
    @Published var listVehiculos = [String] ()
    @Published var listReparaciones = [String] ()
    //Filtro
    @Published var filterDetail: String = ""
    //Firebase
    let db = Firestore.firestore()
    
    
    init()
    {
        fetchAllTalleres()
        fetchAllVehiculos()
        fetchAllReparaciones()
    }
    
    
    func fetchAllTalleres()
    {
           db.collection("COLECCT_DB_CARCARE").document("Talleres").collection("Collect_Talleres").getDocuments(){
               (querySnapshot, error) in
               if let error = error {
               print("Error getting documents: \(error)")
           } else
               {
               for document in querySnapshot!.documents {
               print("\(document.documentID): \(document.data())")
               //self.taller = document.data()
                   let data = document.data()
                   self.listNombreTaller.append(data["nombre"] as? String ?? "")
                  // self.taller = data["nombre"] as? String ?? ""
               }
        }
    }
   }//Fin de la funcion fetchAllTalleres
    
    func fetchAllVehiculos()
    {
        db.collection("COLECCT_DB_CARCARE").document("Vehiculos").collection("Collect_Vehiculos").getDocuments(){
            (querySnapshot, error) in
            if let error = error {
            print("Error getting documents: \(error)")
        } else
            {
            for document in querySnapshot!.documents {
            print("\(document.documentID): \(document.data())")
                let data = document.data()
                let marca = data["Marca"] as? String ?? ""
                let modelo = data["Modelo"] as? String ?? ""
                let vin = data["Vin"] as? String ?? ""
               //self.listVehiculos.append(data["Marca"] as? String ?? "")
                self.listVehiculos.append("\(marca)-\(modelo)")
            }
            }
        }
    }//Fin de la funcion fetchAllVehiculos
    
    func fetchAllReparaciones()
    {
        db.collection("COLECCT_DB_CARCARE").document("Reparaciones").collection("Collect_Reparaciones").getDocuments(){
            (querySnapshot, error) in
            if let error = error {
            print("Error getting documents: \(error)")
        } else
            {
            for document in querySnapshot!.documents {
            print("\(document.documentID): \(document.data())")
                let data = document.data()
                let tipoServicio = data["TipoServicio"] as? String ?? ""
                let datosVehiculo = data["DatosVehiculo"] as? String ?? ""
                self.listReparaciones.append("\(tipoServicio) -\(datosVehiculo)")
            }
            }
        }
    }//Fin de la funcion fetchAllReparacion
    
    
    func vehiculoInfoDetail()
    {
        
        
        
    }//Fin de la funcion fetchVehiculoDetail
    
    
    
    
}//Fin de la class FirestoreManager
