//
//  Reparacion.swift
//  CarCare
//
//  Created by chamuel castillo on 1/25/22.
//

import SwiftUI
import CoreData

struct ReparacionView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @State private var isActive = false
    //Fetch Data
    @Environment(\.managedObjectContext) var moc
    //Firebase
    @ObservedObject var vm = FirestoreManager()
    
    var body: some View {
        
        NavigationView {
        
            List {
                ForEach(vm.listReparaciones, id:\.self){item in
                    NavigationLink{
                        //Detail
                        Text("Info Reparacion")
                        Text(item)
                        
                    } label:
                    {
                        Text(item)
                    }
                }//Fin del ForEach
                
            }//Fin del List
            .navigationTitle("Reparación")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {

                
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
                ToolbarItem {
                    
                    Button(action: {
                        self.isActive = true
                        }, label: {
                           Label("Add Item", systemImage: "plus")
                            
                            NavigationLink(destination: ViewAddReparacion(), isActive: $isActive) { }
                            
                        })
                }
            }
            Text("Select an item")
//            .navigationTitle("Reparaciones")
        }
    }

   

    /*private func deleteReparacion(offsets: IndexSet) {
        withAnimation {
            offsets.map { reparacion[$0] }.forEach(viewContext.delete)

            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }//Fin de la funcion deleteReparacion
     */
    
    
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    return formatter
}()

let dateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    return formatter
}()

struct ReparacionView_Previews: PreviewProvider {
    static var previews: some View {
        ReparacionView().environment(\.managedObjectContext,PersistenceController.preview.container.viewContext)
            .environmentObject(FirestoreManager())
    }
}
