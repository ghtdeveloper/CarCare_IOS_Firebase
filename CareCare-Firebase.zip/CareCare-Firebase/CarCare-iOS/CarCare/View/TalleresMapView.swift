//
//  TalleresView.swift
//  CarCare
//
//  Created by chamuel castillo on 1/26/22.
//

import SwiftUI
import MapKit

struct TalleresMapView: View {
    
    var coordinate: CLLocationCoordinate2D
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 18.4814581, longitude: -69.9697862), span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5))
    @State private var isActive = false
    //Firebase
    @EnvironmentObject var firestoreManager: FirestoreManager
    
    var body: some View {
        
        NavigationView {
            
            
            List {
                ForEach(firestoreManager.listNombreTaller, id:\.self){item in
                    NavigationLink {
                        Map(coordinateRegion: $region)
                        .frame(width: 450, height: 420)
                    } label:{
                        Text(item)
                    }
                }
                           
            }
            .navigationTitle("Talleres")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    //EditButton()
                }
                ToolbarItem {
                    Button(action: {
                        self.isActive = true
                        }, label: {
                           
                            Label("Add Item", systemImage: "plus")
                            NavigationLink(destination: ViewAddTaller(), isActive: $isActive) { }
                            
                        })
                }//Fin ToolbarItem
            }//Fin del toolbar
            
        }
}

}//Fin del body



struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        //TalleresMapView()
        TalleresMapView(coordinate: CLLocationCoordinate2D(latitude: 18.4814581, longitude: -69.9697862)).environmentObject(FirestoreManager())
    
    }
}

