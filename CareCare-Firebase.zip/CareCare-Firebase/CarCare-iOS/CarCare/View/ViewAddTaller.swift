//
//  ViewAddTaller.swift
//  CarCare
//
//  Created by user207369 on 2/5/22.
//

import SwiftUI
import Firebase


struct ViewAddTaller: View {
    
    @State private var nombreTaller = ""
    @State private var direccionTaller = ""
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.managedObjectContext) var moc
    @State  var showAlert = false
    @State private var isActive = false
    //Firebase
    let db = Firestore.firestore()
   
    
    var body: some View {
        

        Text("Registrar taller")
        //Nombre Taller
        TextField("Nombre...", text: $nombreTaller)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        //print("Data Nombre",nombreTaller) 
        
        //Direccion
        TextField("Direccion..", text: $direccionTaller)
                .textFieldStyle(RoundedBorderTextFieldStyle())
       //Save
        Button(action: {
            //showDialog()
            addTaller()
        }) {
            HStack {
                Image(systemName: "save")
                    .font(.title)
                Text("Guardar")
                    .fontWeight(.semibold)
                    .font(.title)
            }
             .frame(maxWidth: 120)
             .padding()
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(30)
            
          
        }
        
        .alert(isPresented: $showAlert) { () -> Alert in
            let button = Alert.Button.default(Text("Continuar"))
            {
                print("Todo ok")
                self.nombreTaller = ""
                self.direccionTaller = ""
            }
            return Alert(title: Text("Registro de taller"),
                         message: Text("Realizado Exitosamente!"), dismissButton: button)
        }
    }
    

    private func addTaller()
     {
         self.moc.performAndWait {
             db.collection("COLECCT_DB_CARCARE").document("Talleres").collection("Collect_Talleres").addDocument(data: [
                "nombre":self.nombreTaller,
                "direccion": self.direccionTaller,
                "latitud": "18.4814581",
                "Longitud": "-69.9697862"
             ]){ err in
                 if let err = err {
                     print("Error adding document: \(err)")
                 } else {
                     self.showAlert.toggle()
                 }
             }
         }
     }//Fin de la funcion addTaller
}

struct ViewAddTaller_Previews: PreviewProvider {
    static var previews: some View {
        ViewAddTaller()
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
