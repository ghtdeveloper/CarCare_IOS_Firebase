//
//  ViewAddVehicle.swift
//  CarCare
//
//  Created by user207369 on 2/5/22.
//

import SwiftUI
import Firebase

struct ViewAddVehicle: View {
    
    @State var markVehicle = ""
    @State var modelVehicle = ""
    @State var yearFabriVehicle = ""
    @State var colorVehicle = ""
    @State var vinVehicle = ""
    @State var aliasVehicle = ""
    @State var tipoVehiculo = ""
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.managedObjectContext) var moc
    @State  var showAlert = false
    @State private var isActive = false
    //Firebase
    let db = Firestore.firestore()
    //Firebase
    @EnvironmentObject var firestoreManager: FirestoreManager
    
    var body: some View {
        Text("Registrar Vehículo")//Titulo
        
        //Marca
        TextField("Marca...", text: $markVehicle)
            .textFieldStyle(RoundedBorderTextFieldStyle())
        //Modelo
        TextField("Modelo...", text: $modelVehicle)
            .textFieldStyle(RoundedBorderTextFieldStyle())
        //Year
        TextField("Año de fabricación...", text: $yearFabriVehicle)
            .textFieldStyle(RoundedBorderTextFieldStyle())
        //Color
        TextField("Color...", text: $colorVehicle)
            .textFieldStyle(RoundedBorderTextFieldStyle())
        //Vin
        TextField("Vin...", text: $vinVehicle)
            .textFieldStyle(RoundedBorderTextFieldStyle())
        //Tipo vehiculo
        TextField("Tipo...", text: $tipoVehiculo)
            .textFieldStyle(RoundedBorderTextFieldStyle())
        //Alias
        TextField("Alias..", text: $aliasVehicle)
            .textFieldStyle(RoundedBorderTextFieldStyle())
        
        //Button Save
        Button(action: {
           addVehiculo()
            //self.showAlert.toggle()
        }) {
            HStack {
                Image(systemName: "add")
                    .font(.title)
                Text("Guardar")
                    .fontWeight(.semibold)
                    .font(.title)
            }
            .padding()
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(30)
        }
        
        .alert(isPresented: $showAlert) { () -> Alert in
            let button = Alert.Button.default(Text("Continuar"))
            {
                print("Todo ok")
                self.markVehicle = ""
                self.modelVehicle = ""
                self.yearFabriVehicle = ""
                self.colorVehicle = ""
                self.vinVehicle = ""
                self.aliasVehicle = ""
                self.tipoVehiculo = ""
            }
            return Alert(title: Text("Registro de vehículo "),
                         message: Text("Realizado Exitosamente!"), dismissButton: button)
    }
        
    }
    
    private func addVehiculo()
     {
         self.moc.performAndWait {
             db.collection("COLECCT_DB_CARCARE").document("Vehiculos").collection("Collect_Vehiculos").addDocument(data: [
                "Marca":self.markVehicle,
                "Modelo": self.modelVehicle,
                "AnioFabricacion": self.yearFabriVehicle,
                "Color": self.colorVehicle,
                "Vin": self.vinVehicle,
                "Alias": self.aliasVehicle,
                "TipoVehiculo": self.tipoVehiculo
             ]){ err in
                 if let err = err {
                     print("Error adding document: \(err)")
                 } else {
                     self.showAlert.toggle()
                 }
             }
         }
     }//Fin de la funcion addVehiculo
        
}

struct ViewAddVehicle_Previews: PreviewProvider {
    static var previews: some View {
        ViewAddVehicle().environmentObject(FirestoreManager())
    }
}
