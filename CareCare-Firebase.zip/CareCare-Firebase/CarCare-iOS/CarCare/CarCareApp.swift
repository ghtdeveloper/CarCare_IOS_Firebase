//
//  CarCareApp.swift
//  CarCare
//
//  Created by chamuel castillo on 1/15/22.
//

import SwiftUI
import Firebase

@main
struct CarCareApp: App {
    
    let persistenceController = PersistenceController.shared
    
    @StateObject var firestoreManager = FirestoreManager()
    
    init(){
        //Init Firebase
        FirebaseApp.configure()
    }
    
    var body: some Scene {
      
        WindowGroup {
            AppView()
                    .environmentObject(firestoreManager)
        }
    }
 
}
