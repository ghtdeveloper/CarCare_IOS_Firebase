//
//  ContentView.swift
//  CarCare
//
//  Created by chamuel castillo on 1/15/22.
//

import SwiftUI
import CoreData

struct VehiculoView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @State private var isActive = false
    //Fetch Data
    @Environment(\.managedObjectContext) var moc
    //Firebase
    @EnvironmentObject var firestoreManager: FirestoreManager
    var body: some View {
  
        NavigationView {
        
            List {
                ForEach(firestoreManager.listVehiculos, id:\.self){item in
                    NavigationLink {
                        Text("Detalle Vehiculo")
                        Text(item)
                    } label:{
                        Text(item)
                    }
                }
                
                //.onDelete(perform: deleteVehiculo)
            }//Fin del List
            .navigationTitle("Vehiculo")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                   EditButton()
                }
                ToolbarItem {
                    
                    Button(action: {
                        self.isActive = true
                        }, label: {
                           Label("Add Item", systemImage: "plus")
                            NavigationLink(destination: ViewAddVehicle(), isActive: $isActive) { }
                            
                        })
                }//Fin ToolbarItem
            }//Fin del toolbar
            Text("Select an item")
//            .navigationTitle("Reparaciones")
        }
    }

    /*private func deleteVehiculo(offsets: IndexSet) {
        withAnimation {
            offsets.map { vehiculo[$0] }.forEach(viewContext.delete)

            do {
                try viewContext.save()
            } catch {
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }//Fin de la funcion deleteVehiculo
     */
    
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        VehiculoView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext).environmentObject(FirestoreManager())
    }
}
