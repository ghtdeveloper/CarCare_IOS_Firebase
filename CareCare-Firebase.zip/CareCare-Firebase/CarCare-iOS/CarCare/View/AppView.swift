//
//  AppView.swift
//  CarCare
//
//  Created by chamuel castillo on 1/25/22.
//

import SwiftUI
import MapKit

struct AppView: View {
    var body: some View {
        TabView{
            ReparacionView()
                .tabItem ({
                    Image(systemName: "wrench.and.screwdriver.fill")
                    Text("Reparacion")
                })
            VehiculoView()
                .tabItem ({
                    Image(systemName: "car.fill")
                    Text("Vehiculo")
                    
                })

           TalleresMapView(coordinate: CLLocationCoordinate2D(latitude: 34.011_286, longitude: -116.166_868))
                .tabItem ({
                    Image(systemName: "map.fill")
                    Text("Talleres")
                })
                .background(Color.green)
        }
    }
}

struct AppView_Previews: PreviewProvider {
    static var previews: some View {
        AppView().environmentObject(FirestoreManager())
    }
}
