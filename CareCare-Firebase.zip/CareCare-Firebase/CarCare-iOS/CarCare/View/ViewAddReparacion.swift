//
//  ViewAddReparacion.swift
//  CarCare
//
//  Created by user207369 on 2/5/22.
//

import SwiftUI
import Firebase

struct ViewAddReparacion: View {
    
   //Variables
    @State var tallerSelected: String = ""
    @State var tipoServicio: String = ""
    @State var notas: String = ""
    @State var fechaEntrada: Date = Date()
    @State var fechaSalida: Date = Date()
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.managedObjectContext) var moc
    @State  var showAlert = false
    @State private var isActive = false
    //Firebase
    let db = Firestore.firestore()
    @EnvironmentObject var firestoreManager: FirestoreManager
    @ObservedObject var vm = FirestoreManager()
    @State var selectVehiculoInfo: String = ""
    @State var selectTallerInfo: String = ""
   
    
    var body: some View {
        Text("Registrar reparación")
        
        Form {
            //Seleccion de vehiculo
                Section {
                    Picker("Vehículo",selection: $selectVehiculoInfo)
                    {
                        ForEach(vm.listVehiculos, id:\.self){item in
                            Text(item)
                        }//Fin del ForEach
                    }
                    //Fecha Entrada
                    DatePicker("Fecha Entrada", selection: $fechaEntrada)
                    //Fecha Salida
                    DatePicker("Fecha Salida", selection: $fechaSalida)
                    
                    //Seleccion de talleres
                    Picker("Taller", selection: $selectTallerInfo) {
                        ForEach(vm.listNombreTaller, id:\.self){item in
                            Text(item)
                        }//Fin del ForEach
                        
                    }//Fin del Picker Taller
                    //Tipo Servicio
                    TextField("Tipo Servicio...", text: $tipoServicio)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    //Notas
                    TextField("Notas..", text: $notas)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                    //Button Save
                        Button(action: {
                           addReparacion()
                        }) {
                            HStack {
                                Image(systemName: "save")
                                    .font(.title)
                                Text("Guardar")
                                    .fontWeight(.semibold)
                                    .font(.title)
                            }
                            .frame(maxWidth: .infinity)
                             .padding()
                            .foregroundColor(.white)
                            .background(Color.blue)
                            .cornerRadius(30)
                        }
                        .alert(isPresented: $showAlert) { () -> Alert in
                            let button = Alert.Button.default(Text("Continuar"))
                            {
                                print("Todo ok")
                                self.notas = ""
                                self.tipoServicio = ""
                                self.selectVehiculoInfo = ""
                                self.selectVehiculoInfo = ""
                                self.fechaEntrada = Date()
                                self.fechaSalida = Date()
                            
                            }
                            return Alert(title: Text("Registro de reparación"),
                                         message: Text("Realizado Exitosamente!"), dismissButton: button)
                }
            }//Fin del section
          
        }//Fin del form
        
       
    }
    
    private func addReparacion()
     {
         self.moc.performAndWait {
             db.collection("COLECCT_DB_CARCARE").document("Reparaciones").collection("Collect_Reparaciones").addDocument(data: [
                "Fechasalida":self.fechaSalida,
                "FechaEntrada": self.fechaEntrada,
                "TipoServicio": self.tipoServicio,
                "Notas": self.notas,
                "DatosVehiculo": self.selectVehiculoInfo,
                "TallerNombre": self.selectTallerInfo
             ]){ err in
                 if let err = err {
                     print("Error adding document: \(err)")
                 } else {
                     self.showAlert.toggle()
                 }
             }
         }//Fin del metodo perfowm And Wait
     }//Fin de la funcion addVehiculo
    
    
}

struct ViewAddReparacion_Previews: PreviewProvider {
    static var previews: some View {
        ViewAddReparacion().environmentObject(FirestoreManager())
    }
}
